import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import Modal from '@mui/material/Modal'

import PropTypes from 'prop-types'
import { useState } from 'react'

import CusSwitch from 'components/sample/Switch'

const style = {
  position: 'absolute',
  top: '20%',
  left: '13%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  boxShadow: 24,
  p: 4
}

function Appbar() {
  const [open, setOpen] = useState(false)
  const handleOpen = () => setOpen(true)
  const handleClose = () => setOpen(false)
  const [backColor, setBackColor] = useState(true)

  return (
    <div
      className='d-flex row justify-content-center align-align-items-center'
      style={{
        width: '100%',
        height: 70,
        backgroundColor: backColor ? '#fff' : '#000'
      }}
    >
      <div>
        <Button onClick={handleOpen}>Open modal</Button>
        <Modal open={open} onClose={handleClose}>
          <Box sx={style}>
            <CusSwitch onChange={() => setBackColor(!backColor)} />
          </Box>
        </Modal>
      </div>
    </div>
  )
}

Appbar.propTypes = {
  window: PropTypes.func
}

export default Appbar
